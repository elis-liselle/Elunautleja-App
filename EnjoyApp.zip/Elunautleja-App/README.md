# Elunautleja-App

# Arendajad:
- Airit Simsel
- Elis-Liselle Soosalu

Mida te teete homme, et elu oleks ilusam ja stressivabam? Mina ei tea kunagi kuhu minna või mida süüa teha või mida põnevat kuskil toimub ja siis ma õhtul avastan, mis kõik oleks võinud olla. Meie toode teab! Ava äpp ja saad iga päev mõne uue idee mida teha, külastada, mis filmi õhtul vaadata või mida süüa teha tuginedes SINU EELISTUSTELE. Näiteks mõnus hommik smuutikausiga, taustal muusikasoovitused, pärast Loomaaeda või uuele näitusele, õhtul restoranisoovitus või mõnus kodune retsept. Samas, see ei sunni millekski, see annab mitmeid põnevaid ja häid ideid, mille peale võibolla ei tulekski. Iga päev on eriline ja üllatab sind uute väljakutsetega. Tunne, et päev läks täiega korda!

# MVP kasutajalood:
- Teha README.md fail (https://www.pivotaltracker.com/n/projects/2567182/stories/182085082)
- Kasutaja tahab, et rakendus ta ära tunneks (https://www.pivotaltracker.com/story/show/182085619)
- Kasutaja tahab asjakohast ja head infot (https://www.pivotaltracker.com/story/show/182085661)
- Kasutaja tahab kergesti hoomatavat ja liigitatud sisu näha (https://www.pivotaltracker.com/story/show/182085908)
- Kasutaja tahab plaanide tegemiseks teada mis ilm õues ootab (https://www.pivotaltracker.com/story/show/182086031)

# Kuidas rakendust käivitada:
- Mine lehele https://developer.android.com/ -> kliki 'Download Android Studio' lingil -> lae alla Android Studio
- Ava allalaetud Android Studio .exe fail ning paigalda arvutisse
- Ava värskelt paigaldatud Android Studio
- vajuta Android Studio-s üleval paremal nurgas olevat "Get from VCS"
- avanenud aknas vali "Repository URL"
- vajaliku URL-i saab Github-ist kätte minnes repositoorimi lehele: https://github.com/elis-liselle/Elunautleja-App
- repositooriumi lehel vajutades rohelisele nupule leiab HTTPS lingi mille saab seal kopeerida
- lisa Github-ist saadud link Android Studios olevasse "URL:" lahtrisse ja vajuta "Clone"
- oota veidi
- rakenduse testimiseks tuleb paigaldada emulaator
- vali ülemiselt toolbarilt "Tools" -> "Device Manager"
- rakenduse paremas servas avanenud aknas vali "Create Device"
- vali "Pixel 3"
- vali "Tiramisu" -> Download
- oota veidi
- vali uuesti "Tools" -> "Device Manager" -> paremal avanenud aknas vali enda seade ja käivita
- Run app (SHIFT + F10)
- avaneb rakendus logimise vaatega, head kasutamist!

